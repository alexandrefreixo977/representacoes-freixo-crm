"use client";

import { useMemo, useState } from "react";

type Section = "Dashboard" | "Agenda" | "Clientes" | "Visitas" | "Tarefas" | "Oportunidades" | "Emails";

const nav: { label: Section; icon: string }[] = [
  { label: "Dashboard", icon: "▦" }, { label: "Agenda", icon: "□" },
  { label: "Clientes", icon: "◎" }, { label: "Visitas", icon: "⌖" },
  { label: "Tarefas", icon: "✓" }, { label: "Oportunidades", icon: "◇" },
  { label: "Emails", icon: "✉" },
];

const clients = [
  { code: "CLI-001", name: "Kwanza Técnica", city: "Luanda", owner: "Marta Sousa", status: "Ativo", last: "Hoje", priority: "Alta" },
  { code: "CLI-002", name: "Atlântico Industrial", city: "Benguela", owner: "Rui Matos", status: "Potencial", last: "08 ago", priority: "Média" },
  { code: "CLI-003", name: "Nova Oficina", city: "Huambo", owner: "Marta Sousa", status: "Ativo", last: "02 ago", priority: "Alta" },
  { code: "CLI-004", name: "Mecânica do Sul", city: "Lubango", owner: "Rui Matos", status: "Sem contacto", last: "18 jul", priority: "Média" },
];

const tasks = [
  { title: "Enviar proposta revista", client: "Kwanza Técnica", time: "Hoje, 14:30", priority: "Alta" },
  { title: "Confirmar visita técnica", client: "Nova Oficina", time: "Hoje, 16:00", priority: "Média" },
  { title: "Follow-up da demonstração", client: "Atlântico Industrial", time: "Amanhã, 09:30", priority: "Alta" },
];

const opportunities = [
  { title: "Equipamento de oficina", client: "Kwanza Técnica", value: "€ 24 500", stage: "Proposta enviada", probability: 60 },
  { title: "Linha de diagnóstico", client: "Atlântico Industrial", value: "€ 18 200", stage: "Necessidade confirmada", probability: 40 },
  { title: "Renovação de ferramentas", client: "Nova Oficina", value: "€ 9 750", stage: "Negociação", probability: 75 },
];

export default function Home() {
  const [showCover, setShowCover] = useState(true);
  const [section, setSection] = useState<Section>("Dashboard");
  const [query, setQuery] = useState("");
  const [showQuick, setShowQuick] = useState(false);
  const [completed, setCompleted] = useState<string[]>([]);
  const visibleClients = useMemo(() => clients.filter(c => `${c.name} ${c.code} ${c.city}`.toLowerCase().includes(query.toLowerCase())), [query]);

  if (showCover) return <main className="project-cover">
    <div className="cover-image" role="img" aria-label="Representações Freixo CRM, gestão comercial para Portugal e Angola" />
    <div className="cover-shade" />
    <section className="cover-panel">
      <span>PLATAFORMA COMERCIAL</span>
      <h1>O seu dia comercial,<br/>mais simples.</h1>
      <p>Clientes, visitas e oportunidades reunidos num só lugar.</p>
      <button onClick={() => setShowCover(false)}>Entrar no CRM <b>→</b></button>
      <small>Ambiente de demonstração · Representações Freixo</small>
    </section>
  </main>;

  return <main className="app-shell">
    <aside className="sidebar">
      <button className="brand" onClick={() => setShowCover(true)} aria-label="Voltar à capa"><div className="brand-mark">RF</div><div><strong>Representações</strong><span>Freixo · CRM</span></div></button>
      <nav>{nav.map(item => <button key={item.label} className={section === item.label ? "active" : ""} onClick={() => setSection(item.label)}><span>{item.icon}</span>{item.label}{item.label === "Tarefas" && <b>5</b>}</button>)}</nav>
      <div className="sidebar-bottom"><button><span>▤</span> Relatórios</button><button><span>⚙</span> Administração</button><div className="profile"><div className="avatar">MS</div><div><strong>Marta Sousa</strong><span>Gestora comercial</span></div><i>⌄</i></div></div>
    </aside>

    <section className="workspace">
      <header><button className="mobile-menu">☰</button><div className="search"><span>⌕</span><input aria-label="Pesquisa global" value={query} onChange={e => setQuery(e.target.value)} placeholder="Pesquisar clientes, tarefas, oportunidades…"/><kbd>⌘ K</kbd></div><button className="icon-button">◌<em>3</em></button><button className="primary" onClick={() => setShowQuick(!showQuick)}>＋ Novo registo</button></header>
      {showQuick && <div className="quick-menu"><strong>Criar novo</strong>{["Cliente", "Visita", "Tarefa", "Oportunidade"].map(x => <button key={x} onClick={() => { setSection(x === "Cliente" ? "Clientes" : x as Section); setShowQuick(false); }}>＋ {x}</button>)}</div>}
      <div className="content">
        {section === "Dashboard" && <Dashboard setSection={setSection} completed={completed} setCompleted={setCompleted}/>} 
        {section === "Clientes" && <Clients rows={visibleClients} query={query} setQuery={setQuery}/>} 
        {section === "Agenda" && <Agenda/>}
        {section === "Visitas" && <Visits/>}
        {section === "Tarefas" && <Tasks completed={completed} setCompleted={setCompleted}/>} 
        {section === "Oportunidades" && <Pipeline/>}
        {section === "Emails" && <Emails/>}
      </div>
    </section>
  </main>;
}

function PageTitle({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: React.ReactNode }) { return <div className="page-title"><div>{eyebrow && <span>{eyebrow}</span>}<h1>{title}</h1></div>{action}</div> }

function Dashboard({ setSection, completed, setCompleted }: { setSection: (s: Section) => void; completed: string[]; setCompleted: (v: string[]) => void }) {
 return <><PageTitle eyebrow="QUARTA-FEIRA, 12 DE AGOSTO" title="Bom dia, Marta" action={<div className="period"><button className="selected">Esta semana</button><button>Este mês</button></div>}/><p className="subtitle">Aqui está o resumo da atividade comercial da sua equipa.</p>
  <div className="stats"><Stat label="Visitas hoje" value="8" note="6 planeadas · 2 concluídas" accent="blue"/><Stat label="Tarefas pendentes" value="14" note="3 em atraso" accent="amber"/><Stat label="Pipeline aberto" value="€ 128 450" note="12 oportunidades" accent="green"/><Stat label="Sem contacto" value="7" note="Há mais de 30 dias" accent="red"/></div>
  <div className="dashboard-grid"><section className="card wide"><CardHead title="Atividade da semana" link="Ver relatório"/><div className="chart"><div className="y-axis"><span>12</span><span>9</span><span>6</span><span>3</span><span>0</span></div>{[[5,4],[8,5],[6,7],[9,6],[7,3]].map((v,i)=><div className="bar-day" key={i}><div className="bars"><i style={{height:v[0]*10}}/><i style={{height:v[1]*10}}/></div><span>{["Seg","Ter","Qua","Qui","Sex"][i]}</span></div>)}</div><div className="legend"><span><i className="dot blue"/>Visitas</span><span><i className="dot green"/>Tarefas concluídas</span></div></section>
   <section className="card"><CardHead title="Próximas visitas" link="Ver agenda" onClick={() => setSection("Agenda")}/><div className="visit-list"><Visit time="10:00" name="Kwanza Técnica" place="Luanda · Presencial" tag="Em curso"/><Visit time="14:30" name="Nova Oficina" place="Huambo · Presencial"/><Visit time="16:00" name="Mecânica do Sul" place="Online · Microsoft Teams"/></div></section>
   <section className="card wide"><CardHead title="Tarefas prioritárias" link="Ver todas" onClick={() => setSection("Tarefas")}/>{tasks.map(t => <div className={`task-row ${completed.includes(t.title)?"done":""}`} key={t.title}><button aria-label="Concluir tarefa" onClick={() => setCompleted(completed.includes(t.title)?completed.filter(x=>x!==t.title):[...completed,t.title])}>✓</button><div><strong>{t.title}</strong><span>{t.client}</span></div><time>{t.time}</time><em className={t.priority.toLowerCase()}>{t.priority}</em></div>)}</section>
   <section className="card"><CardHead title="Pipeline" link="Ver oportunidades" onClick={() => setSection("Oportunidades")}/><div className="pipeline-total"><div><span>Valor ponderado</span><strong>€ 64 780</strong></div><b>+12,4%</b></div>{opportunities.slice(0,3).map(o=><div className="pipeline-row" key={o.title}><div><strong>{o.stage}</strong><span>{o.client}</span></div><b>{o.value}</b></div>)}</section>
  </div></>;
}

function Stat({label,value,note,accent}:{label:string;value:string;note:string;accent:string}){return <div className={`stat ${accent}`}><span>{label}</span><strong>{value}</strong><small>{note}</small></div>}
function CardHead({title,link,onClick}:{title:string;link:string;onClick?:()=>void}){return <div className="card-head"><h2>{title}</h2><button onClick={onClick}>{link} →</button></div>}
function Visit({time,name,place,tag}:{time:string;name:string;place:string;tag?:string}){return <div className="visit"><time>{time}</time><i/><div><strong>{name}</strong><span>{place}</span></div>{tag&&<em>{tag}</em>}</div>}

function Clients({rows,query,setQuery}:{rows:typeof clients;query:string;setQuery:(x:string)=>void}){return <><PageTitle eyebrow="CARTEIRA COMERCIAL" title="Clientes" action={<button className="primary">＋ Novo cliente</button>}/><div className="toolbar"><div className="search inner"><span>⌕</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Nome, NIF, código ou localidade"/></div><button>Todos os vendedores⌄</button><button>Estado⌄</button><button>Prioridade⌄</button></div><div className="table-card"><table><thead><tr><th>Cliente</th><th>Localização</th><th>Responsável</th><th>Último contacto</th><th>Estado</th><th>Prioridade</th></tr></thead><tbody>{rows.map(c=><tr key={c.code}><td><strong>{c.name}</strong><span>{c.code}</span></td><td>{c.city}</td><td>{c.owner}</td><td>{c.last}</td><td><em className="status">{c.status}</em></td><td><em className={c.priority.toLowerCase()}>{c.priority}</em></td></tr>)}</tbody></table>{!rows.length&&<div className="empty">Nenhum cliente corresponde à pesquisa.</div>}</div></>}

function Agenda(){return <><PageTitle eyebrow="PLANEAMENTO" title="Agenda da equipa" action={<button className="primary">＋ Agendar atividade</button>}/><div className="calendar card"><div className="calendar-head"><button>←</button><h2>12 agosto 2026</h2><button>Hoje</button><button>→</button></div>{["09:00","10:00","11:00","12:00","14:00","15:00","16:00"].map((x,i)=><div className="slot" key={x}><time>{x}</time>{i===1&&<div className="event blue-event"><strong>Kwanza Técnica</strong><span>Visita · Marta Sousa</span></div>}{i===4&&<div className="event green-event"><strong>Nova Oficina</strong><span>Demonstração · Rui Matos</span></div>}{i===6&&<div className="event amber-event"><strong>Mecânica do Sul</strong><span>Reunião online</span></div>}</div>)}</div></>}

function Visits(){return <><PageTitle eyebrow="ATIVIDADE COMERCIAL" title="Visitas" action={<button className="primary">＋ Planear visita</button>}/><div className="feature-grid">{[{t:"Em curso",n:"1",d:"Kwanza Técnica · iniciada às 10:04"},{t:"Planeadas",n:"6",d:"Para hoje"},{t:"Concluídas",n:"2",d:"Relatórios registados"}].map(x=><div className="stat blue" key={x.t}><span>{x.t}</span><strong>{x.n}</strong><small>{x.d}</small></div>)}</div><div className="card visit-form"><h2>Registo rápido de visita</h2><div className="form-grid"><label>Cliente<select><option>Selecionar cliente…</option>{clients.map(c=><option key={c.code}>{c.name}</option>)}</select></label><label>Tipo<select><option>Visita comercial</option><option>Visita técnica</option><option>Demonstração</option></select></label><label className="full">Objetivo<textarea placeholder="Qual é o objetivo principal desta visita?"/></label></div><div className="form-actions"><button>Guardar rascunho</button><button className="primary">Iniciar visita</button></div></div></>}

function Tasks({completed,setCompleted}:{completed:string[];setCompleted:(v:string[])=>void}){return <><PageTitle eyebrow="FOLLOW-UP" title="Tarefas" action={<button className="primary">＋ Nova tarefa</button>}/><div className="tabs"><button className="active">A fazer <b>5</b></button><button>Concluídas</button><button>Todas</button></div><section className="card task-page">{tasks.concat([{title:"Rever condições comerciais",client:"Mecânica do Sul",time:"15 ago, 11:00",priority:"Baixa"}]).map(t=><div className={`task-row ${completed.includes(t.title)?"done":""}`} key={t.title}><button onClick={()=>setCompleted(completed.includes(t.title)?completed.filter(x=>x!==t.title):[...completed,t.title])}>✓</button><div><strong>{t.title}</strong><span>{t.client}</span></div><time>{t.time}</time><em className={t.priority.toLowerCase()}>{t.priority}</em></div>)}</section></>}

function Pipeline(){const stages=["Lead identificado","Necessidade confirmada","Proposta enviada","Negociação"];return <><PageTitle eyebrow="VENDAS" title="Pipeline comercial" action={<button className="primary">＋ Nova oportunidade</button>}/><div className="kanban">{stages.map(stage=><section key={stage}><header><strong>{stage}</strong><span>{opportunities.filter(o=>o.stage===stage).length}</span></header>{opportunities.filter(o=>o.stage===stage).map(o=><article key={o.title}><em>{o.client}</em><h3>{o.title}</h3><strong>{o.value}</strong><div className="progress"><i style={{width:`${o.probability}%`}}/></div><small>{o.probability}% probabilidade</small></article>)}{!opportunities.some(o=>o.stage===stage)&&<div className="dropzone">Arraste para esta fase</div>}</section>)}</div></>}

function Emails(){return <><PageTitle eyebrow="MICROSOFT 365" title="Emails" action={<button className="primary">✉ Novo email</button>}/><div className="email-layout"><section className="card integration"><div className="ms-logo">M</div><div><h2>Ligue a sua conta Microsoft 365</h2><p>Envie emails profissionais e associe-os automaticamente à timeline do cliente.</p><span>Modo de demonstração — nenhum email real será enviado.</span></div><button>Ligar conta Microsoft</button></section><section className="card"><CardHead title="Emails recentes" link="Ver todos"/><div className="empty email-empty"><div>✉</div><strong>Ainda não existem emails enviados</strong><span>Os emails enviados com sucesso aparecerão aqui e na ficha do cliente.</span></div></section></div></>}

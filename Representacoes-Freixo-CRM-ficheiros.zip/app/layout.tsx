import type { Metadata } from "next";
import { Geist } from "next/font/google";
import "./globals.css";
import "./theme.css";

const geist = Geist({ variable: "--font-geist", subsets: ["latin"] });
export const metadata: Metadata = {
  title: "Freixo CRM",
  description: "Gestão comercial da Representações Freixo",
  openGraph: { title: "Representações Freixo CRM", description: "Gestão de clientes, visitas comerciais e oportunidades.", images: ["/freixo-crm-cover.png"] },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="pt-PT"><body className={geist.variable}>{children}</body></html>; }
